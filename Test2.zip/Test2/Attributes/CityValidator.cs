﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace Test2.Attributes
{
    

    public sealed class CityValidator : ValidationAttribute
    {
        private readonly string _placeholderValue;

        public override bool IsValid(object value)
        {
            bool retVal = true;
            Regex regExPattern = new Regex("[^a-z0-9]");
            
            var stringValue = string.Empty;
            if (value != null)
            {
                stringValue = value.ToString();
            }
            if (!string.IsNullOrEmpty(stringValue))
            {
                if (!regExPattern.IsMatch(stringValue.ToLower()) && !stringValue.Contains(" ") && !stringValue.ToLower().Contains("city"))
                {
                    retVal = true;
                }
                else
                {
                    ErrorMessage = "Invalid City";
                    retVal = false;

                }
            }
            return retVal;
        }

    }
}