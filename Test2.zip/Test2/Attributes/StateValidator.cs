﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Test2.Attributes
{
    public sealed class StateValidator : ValidationAttribute
    {
         public override bool IsValid(object value)
        {
            bool retVal = true;

            var stringValue = string.Empty;
            if (value != null)
            {
                stringValue = value.ToString();
            }
            if (!string.IsNullOrEmpty(stringValue))
            {
                if (stringValue.ToLower() == "california")
                {
                    retVal = true;
                }
                else
                {
                    ErrorMessage = "Invalid State";
                    retVal = false;

                }
            }
            return retVal;
        }

    }
}