﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Test2.Attributes;

namespace Test2.Models
{
    public class EmployeeViewModel
    {
        [Required(AllowEmptyStrings=false,ErrorMessage="Employee Id is required")]
        [DataType(DataType.Text)]
        [Display(Name = "Employee Id")]
        public int ID { get; set; }


        [Required(AllowEmptyStrings = false, ErrorMessage = "Employee Name is required")]
        [MaxLength(50, ErrorMessage = "Employee Name field can accept a maximum of 50 characters")]
        [DataType(DataType.Text)]
        [Display(Name = "Employee Name")]
        public string Name { get; set; }


        [MaxLength(100, ErrorMessage = "Address field can accept a maximum of 100 characters")]
        [DataType(DataType.Text)]
        [Display(Name = "Address")]
        public string Address { get; set; }


        [MaxLength(50, ErrorMessage = "City field can accept a maximum of 50 characters")]
        [CityValidator()]
        [DataType(DataType.Text)]
        [Display(Name = "City")]
        public string City { get; set; }

        [MaxLength(50, ErrorMessage = "State field can accept a maximum of 50 characters")]
        [StateValidator()]
        [DataType(DataType.Text)]
        [Display(Name = "State")]
        public string State { get; set; }
    }


}